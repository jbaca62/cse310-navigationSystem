This program was written in C++. It is an implementation of a navigation system using Dijkstra's shortest path algorithm. 

Written by: Jacob Baca
Email: jbaca6@asu.edu


How To Use the Program:

On reading S, the program stops.

On reading W, the program writes the current graph information to the screen, and waits for the next command.

On reading R, the program reads in a graph from Ginput.txt

On reading P i v f, the program calculates the shortest path from node i to node v.

