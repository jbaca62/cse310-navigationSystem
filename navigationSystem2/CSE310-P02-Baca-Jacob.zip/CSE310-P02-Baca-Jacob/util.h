#ifndef UTIL_H_INCLUDED
#define UTIL_H_INCLUDED
#include "Edge.h"

int nextCommand(int *i, int *v, int *f);
Edge* read_input_text();

#endif // UTIL_H_INCLUDED
